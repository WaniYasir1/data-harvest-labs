export default [
  {
    id: 'services',
    title: 'Our Services',
    path: '/#services',
  },
  {
    id: 'about',
    title: 'About Us',
    path: '/#about',
  },
  {
    id: 'gwas',
    title: 'GWAS & SNP Analysis',
    path: '/#services',
  },
  {
    id: 'heritability',
    title: 'Heritability & Diversity',
    path: '/#services',
  },
  {
    id: 'contact',
    title: 'Get in Touch',
    path: '/contact',
  },
];
