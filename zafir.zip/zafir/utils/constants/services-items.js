export default [
  [
    'SNP Data Analysis',
    [
      'Genotype quality control & filtering (MAF, HWE, missingness)',
      'Imputation — Beagle, MaCH, IMPUTE2 pipelines',
      'Linkage disequilibrium (LD) analysis & haplotype phasing',
      'Allele frequency spectrum & population stratification',
      'Variant annotation — functional, coding & non-coding regions',
    ],
  ],
  [
    'GWAS — Linear & Mixed Models',
    [
      'Linear Mixed Model (LMM) — EMMAX, GEMMA',
      'Multi-locus models — FarmCPU, BLINK, MLMM',
      'General Linear Model (GLM) with Q-matrix',
      'Population structure & kinship matrix control',
      'Manhattan plots, QQ plots & candidate gene analysis',
    ],
  ],
  [
    'Genomic Diversity Analysis',
    [
      'Population structure — ADMIXTURE, STRUCTURE, fastSTRUCTURE',
      'Principal Component Analysis (PCA)',
      "Nucleotide diversity (\u03c0), Tajima's D, Fst & Gst",
      'Runs of homozygosity (ROH) & inbreeding coefficients',
      'Phylogenetic trees & gene flow analysis',
    ],
  ],
  [
    'Heritability Estimation',
    [
      'Narrow-sense heritability — parent-offspring regression, REML',
      'Genomic heritability — GREML via GCTA / GEMMA',
      'Genomic BLUP (GBLUP) — VanRaden & Yang methods',
      'Variance component decomposition — genetic, residual & GxE',
      'Bivariate models for trait correlations & BayesA/B/C',
    ],
  ],
  [
    'ANOVA & Regression',
    [
      'One-way, two-way & split-plot ANOVA',
      'Multi-environment trial (MET) & GxE interaction analysis',
      "Post-hoc tests — Tukey's HSD, Bonferroni, LSD",
      'Simple, multiple & logistic regression',
      'Regularization — Ridge, LASSO & Elastic Net models',
    ],
  ],
  [
    'Custom Genomic Analytics',
    [
      'Genomic selection & estimated breeding values (EBV)',
      'Selection signature analysis — XP-EHH, iHS, Fst sweeps',
      'GBS, SNP chip & whole-genome sequencing pipelines',
      'Publication-ready figures & reproducible R / Python workflows',
      'Consulting for students, researchers & breeding companies',
    ],
  ],
];
