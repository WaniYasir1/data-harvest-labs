import React from 'react';
import AnimateOnScreen from '../../AnimateOnScreen';
import { ContentSection, TextWrapper, Text } from './styles';

const Content = () => {
  return (
    <AnimateOnScreen>
      <ContentSection>
        <TextWrapper>
          <Text>
            Genomic data is complex and rich with signal—
            <br />
            We decode it. From raw SNP files to publication-ready discoveries,
            Data Harvest Labs delivers rigorous, reproducible genomic analysis
            for plant and animal scientists worldwide.
          </Text>
        </TextWrapper>
      </ContentSection>
    </AnimateOnScreen>
  );
};

export default Content;
