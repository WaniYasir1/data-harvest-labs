export { default } from './CanvasEraser';
